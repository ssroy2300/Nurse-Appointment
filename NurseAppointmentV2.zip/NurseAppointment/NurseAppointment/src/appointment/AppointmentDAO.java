package appointment;

import java.sql.SQLException;
import java.util.List;

import appointment.AppointmentModel;

public interface AppointmentDAO {
	int insert(AppointmentModel app) throws SQLException;
	int update(AppointmentModel app) throws SQLException;
	int delete(AppointmentModel app) throws SQLException;
	AppointmentModel  findbyId(int appointment_id) throws SQLException;
	List<AppointmentModel> findAll() throws SQLException;
}
