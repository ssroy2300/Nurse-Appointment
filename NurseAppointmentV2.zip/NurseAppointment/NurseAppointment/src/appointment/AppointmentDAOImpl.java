package appointment;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nurseappointment.DatabaseCon;

public class AppointmentDAOImpl implements AppointmentDAO{
	
	
	@Override
	public int insert(AppointmentModel app) throws SQLException {
		
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("INSERT INTO Appointment(appoinmentId,userId,nurseId,serviceId) VALUES (?,?,?,?);");
		
		ps.setInt(1, app.getAppointmentId());
		ps.setInt(2, app.getUserId());
		ps.setInt(3, app.getNurseId());
		ps.setInt(4, app.getServiceId());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	@Override
	public AppointmentModel findbyId(int appointment_id) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Appointment WHERE appoinmentId=?");
		
		ps.setInt(1, appointment_id);
		
		ResultSet res = ps.executeQuery();
		AppointmentModel appt = new AppointmentModel();
		while(res.next()) {
			appt.setAppointmentId(res.getInt("appoinmentId"));
			appt.setUserId(res.getInt("userId"));
			appt.setNurseId(res.getInt("nurseId"));
			appt.setServiceId(res.getInt("serviceId"));
		}
		
		ps.close();
		
		return appt;
	}
	
	@Override
	public int update(AppointmentModel cu) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("UPDATE Appointment SET userId=?, nurseId=?, serviceId=? WHERE appoinmentId=?");
		
		ps.setInt(1, cu.getUserId());
		ps.setInt(2, cu.getNurseId());
		ps.setInt(3, cu.getServiceId());
		ps.setInt(4, cu.getAppointmentId());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	
	@Override
	public int delete(AppointmentModel cu) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("DELETE FROM Appointment WHERE appoinmentId=?");
		
		ps.setInt(1, cu.getAppointmentId());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	public List<AppointmentModel> findAll() throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Appointment");
		
		ResultSet res = ps.executeQuery();
		List<AppointmentModel> apts = new ArrayList<AppointmentModel>();
		while(res.next()) {
			AppointmentModel apt = new AppointmentModel();
			apt.setAppointmentId(res.getInt("appoinmentId"));
			apt.setUserId(res.getInt("userId"));
			apt.setNurseId(res.getInt("nurseId"));
			apt.setServiceId(res.getInt("serviceId"));
			apts.add(apt);
		}
		
		ps.close();
		
		return apts;
	}
	

//	@Override
//	public int insert(AppointmentModel app) throws SQLException {
//		// TODO Auto-generated method stub
//		
//			this.conn=conn;
//			
//			String sql="INSERT INTO ap(appoinment_id,user_name,service,user,nurse) VALUES (?,?,?,?)";
//			
//			PreparedStatement ps= conn.prepareStatement(sql);
//			
//			ps.setInt(1, app.getAppointmentId());
//			ps.setString(2, app.getCustomerUserName());
//			ps.setString(3, app.getService());
//			ps.setInt(4, app.getCustomerUserId());
//			ps.setInt(5, app.getNurseId());
//			
//			int result=ps.executeUpdate();
//			
//			DatabaseCon.closePreparedStatement(ps);
//			DatabaseCon.closeConnection(conn);
//			
//		
//	}
//
//	@Override
//	public int update(AppointmentModel app) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="UPDATE nu set appoinment_id=?,user_name=?,service=?,user=?,nurse=? WHERE appoinment_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, app.getAppointmentId());
//		ps.setString(2, app.getCustomerUserName());
//		ps.setString(3, app.getService());
//		ps.setInt(4, app.getCustomerUserId());
//		ps.setInt(5, app.getNurseId());
//		
//		int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	@Override
//	public int delete(AppointmentModel app) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="DELETE FROM ap WHERE appointment_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, app.getAppointmentId());
//		
//      int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	@Override
//	public AppointmentModel findbyId(int appointment_id) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
////		AppointmentModel ap=DatabaseCon.getConnection();
//		AppointmentModel app=null;
//		
//		String sql= "SELECT appoinment_id,user_name,service,user,nurse WHERE appoinment_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, app.getAppointmentId());
//		
//		ResultSet rs=ps.executeQuery();
//		
//		if(rs.next()) {
//			int appoinment_id=rs.getInt("appoinment_id");
//			String user_name=rs.getString("user_name");
//			String service=rs.getString("service");
//			int user=rs.getInt("user");
//			int nurse=rs.getInt("nurse");
//			
//			app=new AppointmentModel(appoinment_id,user_name,service,user,nurse);
//		}
//		
//		return app;
//	}
//
//	@Override
//	public List<AppointmentModel> findAll() throws SQLException {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
