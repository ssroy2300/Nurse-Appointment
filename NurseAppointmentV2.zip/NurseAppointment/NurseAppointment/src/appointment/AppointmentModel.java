package appointment;

import customer.CustomerDAOImpl;
import nurse.NurseDAOImpl;
import service.ServiceDAOImpl;

public class AppointmentModel {
	private int appointment_id;
	private int user_id;
	private int nurse_id;
	private int service_id;
	
	private CustomerDAOImpl custDAO;
	private NurseDAOImpl nurseDAO;
	private ServiceDAOImpl serviceDAO;
	
    public AppointmentModel() {
		custDAO = new CustomerDAOImpl();
		nurseDAO = new NurseDAOImpl();
		serviceDAO = new ServiceDAOImpl();
	}
	
	public AppointmentModel(int appointment_id,int user_id,int nurse_id,int service_id) {
		this.appointment_id=appointment_id;
		this.user_id=user_id;
		this.nurse_id=nurse_id;
		this.service_id=service_id;
		

		custDAO = new CustomerDAOImpl();
		nurseDAO = new NurseDAOImpl();
		serviceDAO = new ServiceDAOImpl();
	}
	
	public void setAppointmentId(int appointment_id) 
	{
		this.appointment_id=appointment_id ;
	}
	public int getAppointmentId() 
	{
		 return this.appointment_id;
    }
	public void setUserId(int user_id) 
	{
		this.user_id=user_id;
	}
	public int getUserId() 
	{
		   return this.user_id;
    }
	public void setNurseId(int nurse_id) 
	{
		this.nurse_id=nurse_id ;
	}
	public int getNurseId() 
	{
		 return this.nurse_id;
    }
	public void setServiceId(int service_id) 
	{
		this.service_id=service_id ;
	}
	public int getServiceId() 
	{
		 return this.service_id;
    }

	
	public void printAppointment() {
		System.out.println("Appointment Id : " +this.appointment_id);
		try {
			custDAO.findbyId(this.user_id).printCustomer();
			nurseDAO.findbyId(this.nurse_id).printNurse();
			serviceDAO.findbyId(this.service_id).printService();	
		} catch (Exception e) {
			System.out.println("There was some error while performing the operation");
		}
}
}
