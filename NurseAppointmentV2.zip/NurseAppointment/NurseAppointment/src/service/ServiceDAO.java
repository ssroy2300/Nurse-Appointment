package service;

import java.sql.SQLException;
import java.util.List;

import service.ServiceModel;

public interface ServiceDAO {
	int insert(ServiceModel cu) throws SQLException;
	int update(ServiceModel cu) throws SQLException;
	int delete(ServiceModel cu) throws SQLException;
	ServiceModel  findbyId(int service_id) throws SQLException;
	List<ServiceModel> findAll() throws SQLException;
}
