package service;

public class ServiceModel {

		private int service_id;
		private String service_description;
		private float service_charges;
		
	    public ServiceModel() {
			
		}
		
		public ServiceModel(int service_id,String service_description,float service_charges) {
			this.setService_id(service_id);
			this.setService_description(service_description);
			this.setService_charges(service_charges);
		}

		public int getService_id() {
			return this.service_id;
		}

		public void setService_id(int service_id) {
			this.service_id = service_id;
		}

		public String getService_description() {
			return this.service_description;
		}

		public void setService_description(String service_description) {
			this.service_description = service_description;
		}

		public float getService_charges() {
			return this.service_charges;
		}

		public void setService_charges(float service_charges) {
			this.service_charges = service_charges;
		}
		
		public void printService() {
			System.out.println("Service Id : " +this.service_id);
			System.out.println("Service Description : " +this.service_description);
			System.out.println("Service Charges : " +this.service_charges);
		}
		
		
	}

