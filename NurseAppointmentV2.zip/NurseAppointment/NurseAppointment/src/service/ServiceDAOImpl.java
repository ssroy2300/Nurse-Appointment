package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nurseappointment.DatabaseCon;

public class ServiceDAOImpl implements ServiceDAO{

	@Override
	public int insert(ServiceModel su) throws SQLException {
		
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("INSERT INTO Service(serviceId,description,charges) VALUES (?,?,?);");
		
		ps.setInt(1, su.getService_id());
		ps.setString(2, su.getService_description());
		ps.setFloat(3, su.getService_charges());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	@Override
	public ServiceModel findbyId(int service_id) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Service WHERE serviceId=?");
		
		ps.setInt(1, service_id);
		
		ResultSet res = ps.executeQuery();
		ServiceModel ser = new ServiceModel();
		while(res.next()) {
			ser.setService_id(res.getInt("serviceId"));
			ser.setService_description(res.getString("description"));
			ser.setService_charges(res.getFloat("charges"));
		}
		
		ps.close();
		
		return ser;
	}
	
	@Override
	public int update(ServiceModel ser) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("UPDATE Service SET  description=?, charges=? WHERE serviceId=?");
		
		ps.setString(1, ser.getService_description());
		ps.setFloat(2, ser.getService_charges());
		ps.setInt(3, ser.getService_id());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	@Override
	public int delete(ServiceModel cu) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("DELETE FROM Service WHERE serviceId=?");
		
		ps.setInt(1, cu.getService_id());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	public List<ServiceModel> findAll() throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Service");
		
		ResultSet res = ps.executeQuery();
		List<ServiceModel> serm = new ArrayList<ServiceModel>();
		while(res.next()) {
			ServiceModel ser = new ServiceModel();
			ser.setService_id(res.getInt("serviceId"));
			ser.setService_description(res.getString("description"));
			ser.setService_charges(res.getFloat("charges"));
			serm.add(ser);
		}
		
		ps.close();
		
		return serm;
	}

	
//	@Override
//	public int insert(ServiceModel su) throws SQLException {
//		
//		Connection conn = DatabaseCon.getConnection();
//		
//		PreparedStatement ps = conn.prepareStatement("INSERT INTO Customer(serviceId,description,charges) VALUES (?,?,?);");
//		
//		ps.setInt(1, su.getService_id());
//		ps.setString(2, su.getService_description());
//		ps.setFloat(3, su.getService_charges());
//		
//		int res = ps.executeUpdate();
//		ps.close();
//		
//		return res;
//	}
//
//	@Override
//	public int update(ServiceModel sc) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="UPDATE sc set service_id=?,description=?,charges=? WHERE service_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, sc.getService_id());
//		ps.setString(4, sc.getService_description());
//		ps.setFloat(5, sc.getService_charges());
//		
//		int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	@Override
//	public int delete(ServiceModel sc) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="DELETE FROM sc WHERE service_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, sc.getService_id());
//		
//    int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	@Override
//	public ServiceModel findbyId(int service_id) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
////		Service sc=Database.getConnection();
//		ServiceModel sc=null;
//		
//		String sql= "SELECT service_id,description,charges WHERE service_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, sc.getService_id());
//		
//		ResultSet rs=ps.executeQuery();
//		
//		if(rs.next()) {
//			int service_id1=rs.getInt("service_id");
//			int description=rs.getInt("description");
//			float charges=rs.getInt("charges");
//			
//			sc=new ServiceModel(service_id1,description,charges);
//		}
//		
//		return sc;
//	}
//
//	@Override
//	public List<ServiceModel> findAll() throws SQLException {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
