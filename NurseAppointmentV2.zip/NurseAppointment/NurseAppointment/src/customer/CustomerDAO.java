package customer;
import java.sql.SQLException;
import java.util.List;

import customer.CustomerModel;

public interface CustomerDAO {
	int insert(CustomerModel cu) throws SQLException;
	int update(CustomerModel cu) throws SQLException;
	int delete(CustomerModel cu) throws SQLException;
	CustomerModel  findbyId(int customer_id) throws SQLException;
	List<CustomerModel> findAll() throws SQLException;
}
