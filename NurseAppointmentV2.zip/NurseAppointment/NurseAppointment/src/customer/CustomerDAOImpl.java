package customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nurseappointment.DatabaseCon;

public class CustomerDAOImpl implements CustomerDAO{
	
	@Override
	public int insert(CustomerModel cu) throws SQLException {
		
			Connection conn = DatabaseCon.getConnection();
			
			PreparedStatement ps = conn.prepareStatement("INSERT INTO Customer(userId,name,address,contactNo) VALUES (?,?,?,?);");
			
			ps.setInt(1, cu.getCustomerId());
			ps.setString(2, cu.getCustomerName());
			ps.setString(3, cu.getCustomerAddress());
			ps.setString(4, cu.getCustomerPhoneno());
			
			int res = ps.executeUpdate();
			ps.close();
			
			return res;
		
	}
	
	@Override
	public CustomerModel findbyId(int customer_id) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Customer WHERE userId=?");
		
		ps.setInt(1, customer_id);
		
		ResultSet res = ps.executeQuery();
		CustomerModel cust = new CustomerModel();
		while(res.next()) {
			cust.setCustomerId(res.getInt("userId"));
			cust.setCustomerName(res.getString("name"));
			cust.setCustomerAddress(res.getString("address"));
			cust.setCustomerPhoneno(res.getString("contactNo"));
		}
		
		ps.close();
		
		return cust;
	}
	
	@Override
	public int update(CustomerModel cu) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("UPDATE Customer SET name=?, address=?, contactNo=? WHERE userId=?");
		
		ps.setString(1, cu.getCustomerName());
		ps.setString(2, cu.getCustomerAddress());
		ps.setString(3, cu.getCustomerPhoneno());
		ps.setInt(4, cu.getCustomerId());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	@Override
	public int delete(CustomerModel cu) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("DELETE FROM Customer WHERE userId=?");
		
		ps.setInt(1, cu.getCustomerId());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	public List<CustomerModel> findAll() throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Customer");
		
		ResultSet res = ps.executeQuery();
		List<CustomerModel> custs = new ArrayList<CustomerModel>();
		while(res.next()) {
			CustomerModel cust = new CustomerModel();
			cust.setCustomerId(res.getInt("userId"));
			cust.setCustomerName(res.getString("name"));
			cust.setCustomerAddress(res.getString("address"));
			cust.setCustomerPhoneno(res.getString("contactNo"));
			custs.add(cust);
		}
		
		ps.close();
		
		return custs;
	}
//    this.conn=conn;
//		
//		String sql="INSERT INTO cu(customer_id,customer_name,customer_address,customer_phoneno) VALUES (?,?,?,?)";
//		
//		PreparedStatement ps= conn.prepareStatement(sql);
//		
//		ps.setInt(1, cu.getCustomerId());
//		ps.setString(2, cu.getCustomerName());
//		ps.setString(3, cu.getCustomerAddress());
//		ps.setInt(4, cu.getCustomerPhoneno());
//		
//		int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//	public int update(CustomerModel cu) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="UPDATE cu set customer_id=?,customer_name=?,customer_address=?,customer_phoneno=? WHERE customer_id=?";
//		
//		PreparedStatement ps=conn.preparedStatement(sql);
//		ps.setInt(1, cu.getCustomerId());
//		ps.setString(2, cu.getCustomerName());
//		ps.setString(3, cu.getCustomerAddress());
//		ps.setInt(1, cu.getCustomerPhoneno());
//		
//		int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	public int delete(CustomerModel cu) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="DELETE FROM cu WHERE customer_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, cu.getCustomerId());
//		
//        int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//	public CustomerModel  findbyId(int customer_id) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
////		Connection cu=DatabaseCon.getConnection();
//		CustomerModel cu=null;
//		
//		String sql= "SELECT customer_id,customer_name,customer_address,customer_phoneno WHERE customer_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, cu.getCustomerId());
//		
//		ResultSet rs=ps.executeQuery();
//		
//		if(rs.next()) {
//			int customer_id1=rs.getInt("customer_id");
//			String customer_name=rs.getString("customer_name");
//			String address=rs.getString("customer_address");
//			int phno=rs.getInt("customer_phoneno");
//			
//			cu=new CustomerModel(customer_id1,customer_name,address,phno);
//		}
//		
//		return cu;
//	}
//	public List<CustomerModel> findAll() throws SQLException {
//		return null;
//	}
}
