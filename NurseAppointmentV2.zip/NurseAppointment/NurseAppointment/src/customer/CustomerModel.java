package customer;

public class CustomerModel {
	
	private int customer_id;
	private String customer_name;
	private String customer_address;
	private String customer_phoneno;
	
	public CustomerModel() {
		
	}
	
	public CustomerModel(int customer_id,String customer_name,String customer_address,String customer_phoneno) {
		this.customer_id=customer_id;
		this.customer_name=customer_name;
		this.customer_address=customer_address;
		this.customer_phoneno=customer_phoneno;
	}
	
	public void setCustomerId(int customer_id) 
	{
		this.customer_id=customer_id ;
	}
	public int getCustomerId() 
	{
		 return this.customer_id;
    }
	public void setCustomerName(String customer_name) 
	{
		this.customer_name=customer_name ;
	}
	public String getCustomerName() 
	{
		   return this.customer_name;
    }
	public void setCustomerAddress(String customer_address) 
	{
		this.customer_address=customer_address ;
	}
	public String getCustomerAddress() 
	{
		 return this.customer_address;
    }
	public void setCustomerPhoneno(String customer_phoneno) 
	{
		this.customer_phoneno=customer_phoneno ;
	}
	public String getCustomerPhoneno() 
	{
		 return this.customer_phoneno;
    }
	
	public void printCustomer() {
		System.out.println("Customer Id : " +this.customer_id);
		System.out.println("Customer Name : " +this.customer_name);
		System.out.println("Customer Address : " +this.customer_address);
		System.out.println("Customer Phone number : " +this.customer_phoneno);
	}

}
