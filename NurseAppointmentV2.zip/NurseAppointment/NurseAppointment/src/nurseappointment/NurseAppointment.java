package nurseappointment;
import customer.CustomerDAOImpl;
import customer.CustomerModel;
import nurse.NurseDAOImpl;
import nurse.NurseModel;
import service.ServiceDAOImpl;
import service.ServiceModel;

import java.util.List;
import java.util.Scanner;

import appointment.AppointmentDAOImpl;
import appointment.AppointmentModel;

public class NurseAppointment {

	public static void main(String[] args) {
		
        Scanner sc = new Scanner(System.in);
        int tempInt;
		String tempString;
		float tempFloat;
        
        int choice1,choice2;
        int result;
        
        System.out.println("1)Customer \n2)Nurse  \n3)Service  \n4)Appointment \nChoice:");
		choice1 = sc.nextInt();
		
		//For Customer
		switch(choice1) {
		case 1:
			System.out.println("1) Insert \n2) Update \n3) Delete \n4) Get All \n5) Get By ID \nChoice:");
			choice2 = sc.nextInt();
			CustomerDAOImpl custDAO  = new CustomerDAOImpl();
			CustomerModel cust;
			
			switch(choice2) {
			case 1:
				CustomerModel custToAdd = new CustomerModel();
				System.out.println("enter customer id: ");
				tempInt = sc.nextInt();
				sc.nextLine();
				custToAdd.setCustomerId(tempInt);
				System.out.println("enter customer name: ");
				tempString = sc.nextLine();
				custToAdd.setCustomerName(tempString);
				System.out.println("enter customer address: ");
				tempString = sc.nextLine();
				custToAdd.setCustomerAddress(tempString);
				System.out.println("enter customer phoneno: ");
				tempString = sc.nextLine();
				custToAdd.setCustomerPhoneno(tempString);
				
				try {
				result = custDAO.insert(custToAdd);
				if(result == 0) 
					System.out.println("Not Inserted");
				else
					System.out.println("Inserted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 2:
				System.out.println("enter the id: ");
				int newid=sc.nextInt();
				sc.nextLine();
				try {
					cust = custDAO.findbyId(newid);
					System.out.println("enter customer phoneno: ");
					tempString = sc.nextLine();
					cust.setCustomerPhoneno(tempString);
					result = custDAO.update(cust);
					if(result == 0) {
						System.out.println("Not Updated");
					} else 
						System.out.println("Updated");
					
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 3:
				System.out.println("enter the id: ");
				int newid1=sc.nextInt();
				try {
					cust = custDAO.findbyId(newid1);
					result = custDAO.delete(cust);
					if(result == 0) {
						System.out.println("Not Deleted");
					} else 
						System.out.println("Deleted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 4:
				try {
					List<CustomerModel> custs = custDAO.findAll();
					for(CustomerModel cu: custs) {
						cu.printCustomer();
						printSeparator();
					}
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
			case 5:
				System.out.println("enter the id: ");
				int newid2=sc.nextInt();
				try {
					cust = custDAO.findbyId(newid2);
					cust.printCustomer();
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
			
			}
			
			break;
			
			
			//For Nurse
		case 2:
			System.out.println("1) Insert \n2) Update \n3) Delete \n4) Get All \n5) Get By ID \nChoice:");
			choice2 = sc.nextInt();
			NurseDAOImpl nurseDAO  = new NurseDAOImpl();
			NurseModel nurse;
			
			switch(choice2) {
			case 1:
				//Insert Nurse
				NurseModel nurseToAdd = new NurseModel();
				System.out.println("enter nurse id: ");
				tempInt = sc.nextInt();
				sc.nextLine();
				nurseToAdd.setNurseId(tempInt);
				System.out.println("enter nurse name: ");
				tempString = sc.nextLine();
				nurseToAdd.setNurseName(tempString);
				System.out.println("enter nurse address: ");
				tempString = sc.nextLine();
				nurseToAdd.setNurseAddress(tempString);
				System.out.println("enter nurse phoneno: ");
				tempString = sc.nextLine();
				nurseToAdd.setNurseContactno(tempString);
				
				try {
				result= nurseDAO.insert(nurseToAdd);
				if(result == 0) 
					System.out.println("Not Inserted");
				else
					System.out.println("Inserted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 2:
				//Update Nurse
				System.out.println("enter the id: ");
				int newid=sc.nextInt();
				sc.nextLine();
				try {
					nurse = nurseDAO.findbyId(newid);
					System.out.println("enter nurse phoneno: ");
					tempString = sc.nextLine();
					nurse.setNurseContactno(tempString);
					result = nurseDAO.update(nurse);
					if(result == 0) {
						System.out.println("Not Updated");
					} else 
						System.out.println("Updated");
					
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 3:
				//Delete Nurse
				System.out.println("enter the id: ");
				int newid1=sc.nextInt();
				try {
					nurse = nurseDAO.findbyId(newid1);
					result = nurseDAO.delete(nurse);
					if(result == 0) {
						System.out.println("Not Deleted");
					} else 
						System.out.println("Deleted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 4:
				//Get all Nurse
				try {
					List<NurseModel> Nurse = nurseDAO.findAll();
					for(NurseModel nu: Nurse) {
						nu.printNurse();
						printSeparator();
					}
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
			case 5:
				//Get by id Nurse
				System.out.println("enter the id: ");
				int newid2=sc.nextInt();
				try {
					nurse = nurseDAO.findbyId(newid2);
					nurse.printNurse();
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
			
			}
			
		    break;
		    //For Service
        case 3:
        	System.out.println("1) Insert \n2) Update \n3) Delete \n4) Get All \n5) Get By ID \nChoice:");
			choice2 = sc.nextInt();
			ServiceDAOImpl serviceDAO  = new ServiceDAOImpl();
			ServiceModel service;
			switch(choice2) {
			case 1:
				//Insert Service
				ServiceModel serviceToAdd = new ServiceModel();
				System.out.println("enter service id: ");
				tempInt = sc.nextInt();
				sc.nextLine();
				serviceToAdd.setService_id(tempInt);
				System.out.println("enter service description: ");
				tempString = sc.nextLine();
				serviceToAdd.setService_description(tempString);
				System.out.println("enter service charges: ");
			    tempFloat = sc.nextFloat();
				serviceToAdd.setService_charges(tempFloat);
				try {
					result= serviceDAO.insert(serviceToAdd);
					if(result == 0) 
						System.out.println("Not Inserted");
					else
						System.out.println("Inserted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 2:
				//Update Service
				System.out.println("enter the id: ");
				int newid=sc.nextInt();
				
				try {
					service = serviceDAO.findbyId(newid);
					System.out.println("enter new charges: ");
					tempFloat = sc.nextFloat();
					service.setService_charges(tempFloat);
					result = serviceDAO.update(service);
					if(result == 0) {
						System.out.println("Not Updated");
					} else 
						System.out.println("Updated");
					
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 3:
				//Delete Service
				System.out.println("enter the id: ");
				int newid1=sc.nextInt();
				try {
					service = serviceDAO.findbyId(newid1);
					result = serviceDAO.delete(service);
					if(result == 0) {
						System.out.println("Not Deleted");
					} else 
						System.out.println("Deleted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
				
			case 4:
				//Get all Service
				try {
					List<ServiceModel> Service = serviceDAO.findAll();
					for(ServiceModel su: Service) {
						su.printService();
						printSeparator();
					}
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
			case 5:
				//Get by id Service
				System.out.println("enter the id: ");
				int newid2=sc.nextInt();
				try {
					service = serviceDAO.findbyId(newid2);
					service.printService();
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
				break;
			
			}
			
		    break;
		    //For Appointment
         case 4:
        	 
        	 System.out.println("1) Insert \n2) Update \n3) Delete \n4) Get All \n5) Get By ID \nChoice:");
 			choice2 = sc.nextInt();
 			AppointmentDAOImpl appointmentDAO  = new AppointmentDAOImpl();
			AppointmentModel app;
 			switch(choice2) {
 			case 1:
 				//Insert appoinment
 				AppointmentModel appToAdd = new AppointmentModel();
				System.out.println("enter appointment id: ");
				tempInt = sc.nextInt();
				appToAdd.setAppointmentId(tempInt);
				System.out.println("enter user: ");
				tempInt = sc.nextInt();
				appToAdd.setUserId(tempInt);
				System.out.println("enter nurse: ");
				tempInt = sc.nextInt();
				appToAdd.setNurseId(tempInt);
				System.out.println("enter service: ");
				tempInt = sc.nextInt();
				appToAdd.setServiceId(tempInt);
				
				try {
					result= appointmentDAO.insert(appToAdd);
					if(result == 0) 
						System.out.println("Not Inserted");
					else
						System.out.println("Inserted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
 				break;
 				
 			case 2:
 				//Update appointment
 				System.out.println("enter the id: ");
				int newid=sc.nextInt();
				
				try {
					app = appointmentDAO.findbyId(newid);
					System.out.println("enter new service id: ");
					tempInt = sc.nextInt();
					app.setServiceId(tempInt);
					result = appointmentDAO.update(app);
					if(result == 0) {
						System.out.println("Not Updated");
					} else 
						System.out.println("Updated");
					
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
 				break;
 				
 			case 3:
 				//Delete services
 				System.out.println("enter the id: ");
				int newid1=sc.nextInt();
				try {
					app = appointmentDAO.findbyId(newid1);
					result = appointmentDAO.delete(app);
					if(result == 0) {
						System.out.println("Not Deleted");
					} else 
						System.out.println("Deleted");
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
 				break;
 				
 			case 4:
 				//Get all services
 				try {
					List<AppointmentModel> App = appointmentDAO.findAll();
					for(AppointmentModel au: App) {
						au.printAppointment();
						printSeparator();
					}
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
 				break;
 			case 5:
 				//Get by id services
 				System.out.println("enter the id: ");
				int newid2=sc.nextInt();
				try {
					app = appointmentDAO.findbyId(newid2);
					app.printAppointment();
				} catch(Exception e) {
					e.printStackTrace();
					System.out.println("There was some issue while performing the operation");
				}
 				break;
 			
 			}
			
		    break;
		}
		
		sc.close();
	}
		    

		
	   
	
	public static void printSeparator() {
		System.out.println("------------------------------------------------------------------------");
	}
}
