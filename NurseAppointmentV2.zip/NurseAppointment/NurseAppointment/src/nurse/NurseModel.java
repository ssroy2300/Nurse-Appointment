package nurse;

public class NurseModel {
	  int nurse_id;
	  String nurse_name;
	  String nurse_address;
	  String nurse_contactno;
	  
	  public NurseModel() {
		  
	  }
	  
	  public NurseModel(int nurse_id,String nurse_name,String nurse_address,String nurse_contactno) {
		  this.nurse_id=nurse_id;
		  this.nurse_name=nurse_name;
		  this.nurse_address=nurse_address;
		  this.nurse_contactno=nurse_contactno;
	  }

	  public void setNurseId(int nurse_id) 
		{
			this.nurse_id=nurse_id ;
		}
		public int getNurseId() 
		{
			 return this.nurse_id;
	    }
		public void setNurseName(String nurse_name) 
		{
			this.nurse_name=nurse_name ;
		}
		public String getNurseName() 
		{
			   return this.nurse_name;
	    }
		public void setNurseAddress(String nurse_address) 
		{
			this.nurse_address=nurse_address ;
		}
		public String getNurseAddress() 
		{
			 return this.nurse_address;
	    }
		public void setNurseContactno(String nurse_contactno) 
		{
			this.nurse_contactno=nurse_contactno ;
		}
		public String getNurseContactno() 
		{
			 return this.nurse_contactno;
	    }
		
		public void printNurse() {
			System.out.println("Nurse Id : " +this.nurse_id);
			System.out.println("Nurse Name : " +this.nurse_name);
			System.out.println("Nurse Address : " +this.nurse_address);
			System.out.println("Nurse Phone number : " +this.nurse_contactno);
		}
}
