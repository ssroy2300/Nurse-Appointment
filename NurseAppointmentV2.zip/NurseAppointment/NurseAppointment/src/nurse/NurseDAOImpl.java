package nurse;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import nurseappointment.DatabaseCon;

public class NurseDAOImpl implements NurseDAO {
	
	@Override
	public int insert(NurseModel nu) throws SQLException {
		
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("INSERT INTO Nurse(nurseId,name,address,contactNo) VALUES (?,?,?,?);");
		
		ps.setInt(1, nu.getNurseId());
		ps.setString(2, nu.getNurseName());
		ps.setString(3, nu.getNurseAddress());
		ps.setString(4, nu.getNurseContactno());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}

	@Override
	public  NurseModel findbyId(int nurse_id) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Nurse WHERE nurseId=?");
		
		ps.setInt(1, nurse_id);
		
		ResultSet res = ps.executeQuery();
		NurseModel apt = new NurseModel();
		while(res.next()) {
			apt.setNurseId(res.getInt("nurseId"));
			apt.setNurseName(res.getString("name"));
			apt.setNurseAddress(res.getString("address"));
			apt.setNurseContactno(res.getString("contactNo"));
		}
		
		ps.close();
		
		return apt;
	}
	
	@Override
	public int update(NurseModel nu) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("UPDATE Nurse SET name=?, address=?, contactNo=? WHERE nurseId=?");
		
		
		ps.setString(1, nu.getNurseName());
		ps.setString(2, nu.getNurseAddress());
		ps.setString(3, nu.getNurseContactno());
		ps.setInt(4, nu.getNurseId());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	@Override
	public int delete(NurseModel nu) throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("DELETE FROM Nurse WHERE nurseId=?");
		
		ps.setInt(1, nu.getNurseId());
		
		int res = ps.executeUpdate();
		ps.close();
		
		return res;
	}
	
	public List<NurseModel> findAll() throws SQLException {
		Connection conn = DatabaseCon.getConnection();
		
		PreparedStatement ps = conn.prepareStatement("SELECT * FROM Nurse");
		
		ResultSet res = ps.executeQuery();
		List<NurseModel> nu = new ArrayList<NurseModel>();
		while(res.next()) {
			NurseModel nums = new NurseModel();
			nums.setNurseId(res.getInt("nurseId"));
			nums.setNurseName(res.getString("name"));
			nums.setNurseAddress(res.getString("address"));
			nums.setNurseContactno(res.getString("contactNo"));
			nu.add(nums);
		}
		
		ps.close();
		
		return nu;
	}
//	@Override
//	public int insert(NurseModel nu) throws SQLException {
//this.conn=conn;
//		
//		String sql="INSERT INTO nu(nurse_id,nurse_name,nurse_address,nurse_phno) VALUES (?,?,?,?)";
//		
//		PreparedStatement ps= conn.prepareStatement(sql);
//		
//		ps.setInt(1, nu.getNurseId());
//		ps.setString(2, nu.getNurseName());
//		ps.setString(3, nu.getNurseAddress());
//		ps.setInt(4, nu.getNurseContactno());
//		
//		int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	@Override
//	public int update(NurseModel nu) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="UPDATE nu set nurse_id=?,nurse_name=?,nurse_address=?,nurse_phno=? WHERE nurse_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, nu.getNurseId());
//		ps.setString(2, nu.getNurseName());
//		ps.setString(3, nu.getNurseAddress());
//		ps.setInt(1, nu.getNurseContactno());
//		
//		int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	@Override
//	public int delete(NurseModel nu) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
//		String sql="DELETE FROM cu WHERE nurse_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, nu.getNurseId());
//		
//        int result=ps.executeUpdate();
//		
//		DatabaseCon.closePreparedStatement(ps);
//		DatabaseCon.closeConnection(conn);
//		
//		return result;
//	}
//
//	@Override
//	public NurseModel findbyId(int customer_id) throws SQLException {
//		Connection conn=DatabaseCon.getConnection();
////		NurseRecord nu=DatabaseCon.getConnection();
//		NurseModel nu=null;
//		
//		String sql= "SELECT nurse_id,nurse_name,nurse_address,nurse_phno WHERE nurse_id=?";
//		
//		PreparedStatement ps=conn.prepareStatement(sql);
//		ps.setInt(1, nu.getNurseId());
//		
//		ResultSet rs=ps.executeQuery();
//		
//		if(rs.next()) {
//			int nurse_id=rs.getInt("nurse_id");
//			String nurse_name=rs.getString("nurse_name");
//			String nurse_address=rs.getString("nurse_address");
//			int nurse_phno=rs.getInt("nurse_phno");
//			
//			nu=new NurseModel(nurse_id,nurse_name,nurse_address,nurse_phno);
//		}
//		
//		return nu;
//	}
//
//	@Override
//	public List<NurseModel> findAll() throws SQLException {
//		// TODO Auto-generated method stub
//		return null;
//	}

}
