package nurse;

import java.sql.SQLException;
import java.util.List;

import nurse.NurseModel;

public interface NurseDAO {
	int insert(NurseModel cu) throws SQLException;
	int update(NurseModel cu) throws SQLException;
	int delete(NurseModel cu) throws SQLException;
	NurseModel  findbyId(int customer_id) throws SQLException;
	List<NurseModel> findAll() throws SQLException;
}
